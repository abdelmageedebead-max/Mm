═══════════════════════════════════════════════════════════════
  30 Python Helper Scripts
  CairoSoftware - www.cairosoftware.com
═══════════════════════════════════════════════════════════════

CONTENTS:
  01-file-processing.py  - File & Folder Management (10 scripts)
  02-automation-data.py  - Automation & Data Handling (10 scripts)
  03-images-media.py     - Image & Media Processing (10 scripts)

INSTALLATION:
  Some scripts require additional packages:
  pip install pillow qrcode[pil]

USAGE:
  Each script is a standalone function.
  Copy the function you need into your project.
  Read the comments above each function for instructions.

═══════════════════════════════════════════════════════════════
  © 2026 CairoSoftware. All Rights Reserved.
═══════════════════════════════════════════════════════════════