"""
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝

Automation & Data Scripts — 10 Ready-to-Use Python Scripts
"""

import os
import json
import csv
import re
from pathlib import Path
from datetime import datetime, timedelta

# ============================================================
# 11. Download File from URL
# ============================================================
def download_file(url, save_path=None):
    """Download a file from a URL with progress bar."""
    import urllib.request
    
    if save_path is None:
        save_path = url.split('/')[-1] or 'downloaded_file'
    
    def show_progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            percent = min(100, downloaded * 100 / total_size)
            print(f"\rDownloading: {percent:.0f}% ({downloaded}/{total_size})", end='')
    
    try:
        print(f"Downloading: {url}")
        urllib.request.urlretrieve(url, save_path, show_progress)
        print(f"\nSaved to: {save_path}")
    except Exception as e:
        print(f"Error: {e}")

# Usage: download_file("https://example.com/file.pdf", "file.pdf")


# ============================================================
# 12. Send Email with Attachment
# ============================================================
def send_email(to_email, subject, body, attachment_path=None, smtp_server="smtp.gmail.com", smtp_port=587):
    """Send an email with optional attachment."""
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.base import MIMEBase
    from email import encoders
    import getpass
    
    sender_email = input("Your email: ")
    password = getpass.getpass("Your password: ")
    
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    
    if attachment_path and Path(attachment_path).exists():
        with open(attachment_path, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename="{Path(attachment_path).name}"')
            msg.attach(part)
    
    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(sender_email, password)
        server.send_message(msg)
        server.quit()
        print("Email sent successfully!")
    except Exception as e:
        print(f"Error sending email: {e}")

# Usage: send_email("friend@email.com", "Hello", "This is a test", "file.pdf")


# ============================================================
# 13. Schedule a Task to Run Later
# ============================================================
def schedule_task(minutes, task_function, *args):
    """Run a function after a specified number of minutes."""
    import time
    
    print(f"Task scheduled to run in {minutes} minutes...")
    time.sleep(minutes * 60)
    print("Running task now...")
    task_function(*args)

# Usage: schedule_task(5, print, "Hello after 5 minutes!")


# ============================================================
# 14. Monitor Website Availability
# ============================================================
def monitor_website(url, check_interval_seconds=300):
    """Monitor a website and alert if it goes down."""
    import time
    import urllib.request
    
    print(f"Monitoring {url} every {check_interval_seconds} seconds...")
    
    while True:
        try:
            start = time.time()
            response = urllib.request.urlopen(url, timeout=10)
            elapsed = (time.time() - start) * 1000
            print(f"[{datetime.now().strftime('%H:%M:%S')}] UP - {response.getcode()} - {elapsed:.0f}ms")
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] DOWN - {e}")
        
        time.sleep(check_interval_seconds)

# Usage: monitor_website("https://www.example.com", 60)


# ============================================================
# 15. Extract Emails from Text
# ============================================================
def extract_emails(text_or_file):
    """Extract all email addresses from text or a file."""
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    
    if Path(text_or_file).exists():
        text = Path(text_or_file).read_text(encoding='utf-8')
    else:
        text = text_or_file
    
    emails = list(set(re.findall(email_pattern, text)))
    emails.sort()
    
    print(f"Found {len(emails)} unique email addresses:")
    for email in emails:
        print(f"  {email}")
    
    return emails

# Usage: extract_emails("document.txt")


# ============================================================
# 16. Generate Random Password
# ============================================================
def generate_password(length=16, include_symbols=True):
    """Generate a strong random password."""
    import string
    import secrets
    
    chars = string.ascii_letters + string.digits
    if include_symbols:
        chars += "!@#$%^&*"
    
    password = ''.join(secrets.choice(chars) for _ in range(length))
    return password

# Usage: print(generate_password(20))


# ============================================================
# 17. Count Words in a File
# ============================================================
def count_words(file_path):
    """Count words, lines, and characters in a text file."""
    file_path = Path(file_path)
    if not file_path.exists():
        print(f"File not found: {file_path}")
        return
    
    text = file_path.read_text(encoding='utf-8')
    words = text.split()
    lines = text.split('\n')
    
    print(f"File: {file_path.name}")
    print(f"Lines: {len(lines)}")
    print(f"Words: {len(words)}")
    print(f"Characters: {len(text)}")
    print(f"Characters (no spaces): {len(text.replace(' ', ''))}")

# Usage: count_words("article.txt")


# ============================================================
# 18. Create Project Folder Structure
# ============================================================
def create_project_structure(base_path, structure):
    """Create a folder and file structure from a dictionary."""
    base = Path(base_path)
    base.mkdir(parents=True, exist_ok=True)
    
    def create_from_dict(current_path, struct):
        for name, content in struct.items():
            item_path = current_path / name
            if isinstance(content, dict):
                item_path.mkdir(exist_ok=True)
                create_from_dict(item_path, content)
            elif content is None:
                item_path.mkdir(exist_ok=True)
            else:
                item_path.write_text(str(content), encoding='utf-8')
                print(f"Created file: {item_path}")
    
    create_from_dict(base, structure)
    print(f"Project structure created at: {base}")

# Usage:
# structure = {
#     "my_project": {
#         "src": {"main.py": "# Main file", "utils.py": "# Utilities"},
#         "tests": {"test_main.py": "# Tests"},
#         "README.md": "# My Project",
#         "requirements.txt": ""
#     }
# }
# create_project_structure(".", structure)


# ============================================================
# 19. JSON to CSV Converter
# ============================================================
def json_to_csv(json_path, csv_path=None):
    """Convert a JSON file to CSV format."""
    json_file = Path(json_path)
    if not json_file.exists():
        print(f"File not found: {json_path}")
        return
    
    if csv_path is None:
        csv_path = json_file.with_suffix('.csv')
    
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if not isinstance(data, list):
            data = [data]
        
        if data:
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
            
            print(f"Converted: {json_file.name} -> {Path(csv_path).name}")
            print(f"Rows: {len(data)}")
    except Exception as e:
        print(f"Error: {e}")

# Usage: json_to_csv("data.json", "data.csv")


# ============================================================
# 20. Simple Web Scraper
# ============================================================
def simple_scraper(url, selector=None):
    """Scrape text content from a webpage."""
    try:
        import urllib.request
        import re
        
        response = urllib.request.urlopen(url, timeout=10)
        html = response.read().decode('utf-8')
        
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', html)
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        print(f"Page title: {re.search(r'<title>(.*?)</title>', html, re.IGNORECASE)}")
        
        if selector:
            pattern = re.compile(f'<{selector}[^>]*>(.*?)</{selector}>', re.IGNORECASE | re.DOTALL)
            matches = pattern.findall(html)
            for i, match in enumerate(matches[:10], 1):
                clean = re.sub(r'<[^>]+>', ' ', match).strip()
                clean = re.sub(r'\s+', ' ', clean)
                print(f"\n--- Match {i} ---")
                print(clean[:200])
        
        return text
    except Exception as e:
        print(f"Error: {e}")
        return None

# Usage: simple_scraper("https://example.com", "p")

"""
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
"""