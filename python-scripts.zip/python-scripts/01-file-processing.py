"""
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝

File Processing Scripts — 10 Ready-to-Use Python Scripts
"""

import os
import shutil
import hashlib
import zipfile
import csv
import json
from pathlib import Path

# ============================================================
# 1. Organize Files by Extension
# ============================================================
def organize_files_by_extension(folder_path):
    """Organize all files in a folder into subfolders by extension."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    for file in folder.iterdir():
        if file.is_file():
            ext = file.suffix.lower().replace('.', '')
            if not ext:
                ext = 'no_extension'
            dest_folder = folder / ext
            dest_folder.mkdir(exist_ok=True)
            shutil.move(str(file), str(dest_folder / file.name))
            print(f"Moved: {file.name} -> {ext}/")

# Usage: organize_files_by_extension("C:/Users/Downloads")


# ============================================================
# 2. Rename Files in Bulk
# ============================================================
def bulk_rename(folder_path, old_text, new_text):
    """Replace text in all filenames within a folder."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    count = 0
    for file in folder.iterdir():
        if file.is_file() and old_text in file.stem:
            new_name = file.stem.replace(old_text, new_text) + file.suffix
            new_path = folder / new_name
            file.rename(new_path)
            count += 1
            print(f"Renamed: {file.name} -> {new_name}")
    
    print(f"Total files renamed: {count}")

# Usage: bulk_rename("C:/Photos", "IMG_", "Vacation_")


# ============================================================
# 3. Find Duplicate Files
# ============================================================
def find_duplicate_files(folder_path):
    """Find duplicate files by comparing their MD5 hash."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    hashes = {}
    duplicates = []
    
    for file in folder.rglob('*'):
        if file.is_file():
            file_hash = hashlib.md5(file.read_bytes()).hexdigest()
            if file_hash in hashes:
                duplicates.append((str(file), str(hashes[file_hash])))
            else:
                hashes[file_hash] = file
    
    if duplicates:
        print(f"Found {len(duplicates)} duplicate files:")
        for dup, orig in duplicates:
            print(f"  Duplicate: {dup}")
            print(f"  Original:  {orig}\n")
    else:
        print("No duplicate files found.")

# Usage: find_duplicate_files("C:/Documents")


# ============================================================
# 4. Delete Empty Folders
# ============================================================
def delete_empty_folders(root_path):
    """Recursively delete all empty folders in a directory."""
    root = Path(root_path)
    if not root.exists():
        print(f"Path not found: {root_path}")
        return
    
    count = 0
    for folder in sorted(root.rglob('*'), reverse=True):
        if folder.is_dir() and not any(folder.iterdir()):
            folder.rmdir()
            count += 1
            print(f"Deleted empty folder: {folder}")
    
    print(f"Total empty folders deleted: {count}")

# Usage: delete_empty_folders("C:/Projects")


# ============================================================
# 5. Extract ZIP Files in Batch
# ============================================================
def batch_extract_zip(folder_path, dest_folder=None):
    """Extract all ZIP files in a folder."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    if dest_folder is None:
        dest_folder = folder
    
    dest = Path(dest_folder)
    dest.mkdir(exist_ok=True)
    
    for file in folder.glob('*.zip'):
        try:
            with zipfile.ZipFile(file, 'r') as zip_ref:
                extract_path = dest / file.stem
                extract_path.mkdir(exist_ok=True)
                zip_ref.extractall(extract_path)
                print(f"Extracted: {file.name} -> {extract_path}")
        except Exception as e:
            print(f"Error extracting {file.name}: {e}")

# Usage: batch_extract_zip("C:/Downloads")


# ============================================================
# 6. Convert CSV to JSON
# ============================================================
def csv_to_json(csv_path, json_path=None):
    """Convert a CSV file to JSON format."""
    csv_file = Path(csv_path)
    if not csv_file.exists():
        print(f"File not found: {csv_path}")
        return
    
    if json_path is None:
        json_path = csv_file.with_suffix('.json')
    
    try:
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            data = list(reader)
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print(f"Converted: {csv_file.name} -> {Path(json_path).name}")
        print(f"Rows: {len(data)}")
    except Exception as e:
        print(f"Error: {e}")

# Usage: csv_to_json("data.csv", "data.json")


# ============================================================
# 7. Merge Multiple Text Files
# ============================================================
def merge_text_files(folder_path, output_file="merged.txt", extension=".txt"):
    """Merge all text files in a folder into one file."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    files = sorted(folder.glob(f'*{extension}'))
    
    with open(output_file, 'w', encoding='utf-8') as outfile:
        for file in files:
            outfile.write(f"\n=== {file.name} ===\n\n")
            outfile.write(file.read_text(encoding='utf-8'))
            outfile.write('\n')
            print(f"Added: {file.name}")
    
    print(f"Merged {len(files)} files into: {output_file}")

# Usage: merge_text_files("C:/Notes", "all_notes.txt")


# ============================================================
# 8. Split Large File into Parts
# ============================================================
def split_file(file_path, chunk_size_mb=10):
    """Split a large file into smaller chunks."""
    file_path = Path(file_path)
    if not file_path.exists():
        print(f"File not found: {file_path}")
        return
    
    chunk_size = int(chunk_size_mb * 1024 * 1024)  # Add int() here
    file_size = file_path.stat().st_size
    
    with open(file_path, 'rb') as f:
        chunk_num = 0
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunk_num += 1
            chunk_name = f"{file_path.stem}_part{chunk_num:03d}{file_path.suffix}"
            with open(chunk_name, 'wb') as chunk_file:
                chunk_file.write(chunk)
            print(f"Created: {chunk_name}")
    
    print(f"Split into {chunk_num} parts of {chunk_size_mb}MB each")

# Usage: split_file("large_file.zip", 10)


# ============================================================
# 9. Get File and Folder Statistics
# ============================================================
def folder_stats(folder_path):
    """Get statistics about files and folders."""
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    total_files = 0
    total_folders = 0
    total_size = 0
    extensions = {}
    
    for item in folder.rglob('*'):
        if item.is_file():
            total_files += 1
            size = item.stat().st_size
            total_size += size
            ext = item.suffix.lower() or 'no_extension'
            extensions[ext] = extensions.get(ext, 0) + 1
        elif item.is_dir():
            total_folders += 1
    
    print(f"Folder: {folder}")
    print(f"Total files: {total_files}")
    print(f"Total folders: {total_folders}")
    print(f"Total size: {total_size / (1024*1024):.1f} MB")
    print(f"\nFile types:")
    for ext, count in sorted(extensions.items(), key=lambda x: x[1], reverse=True):
        print(f"  {ext}: {count} files")

# Usage: folder_stats("C:/Projects")


# ============================================================
# 10. Backup Folder with Timestamp
# ============================================================
def backup_folder(source_folder, backup_folder=None):
    """Create a timestamped backup of a folder."""
    from datetime import datetime
    
    source = Path(source_folder)
    if not source.exists():
        print(f"Folder not found: {source_folder}")
        return
    
    if backup_folder is None:
        backup_folder = source.parent / "backups"
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"{source.name}_{timestamp}"
    backup_path = Path(backup_folder) / backup_name
    
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.make_archive(str(backup_path), 'zip', source)
    
    print(f"Backup created: {backup_path}.zip")

# Usage: backup_folder("C:/MyProject")

"""
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
"""