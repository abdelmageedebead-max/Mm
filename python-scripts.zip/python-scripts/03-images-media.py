"""
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝

Image & Media Scripts — 10 Ready-to-Use Python Scripts
Requirements: pip install pillow
"""

import os
from pathlib import Path

# ============================================================
# 21. Resize Images in Batch
# ============================================================
def batch_resize_images(folder_path, width, height=None, output_folder=None):
    """Resize all images in a folder to specified dimensions."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    if output_folder is None:
        output_folder = folder / "resized"
    output_folder = Path(output_folder)
    output_folder.mkdir(exist_ok=True)
    
    extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
    count = 0
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                if height:
                    img = img.resize((width, height), Image.LANCZOS)
                else:
                    ratio = width / img.width
                    new_height = int(img.height * ratio)
                    img = img.resize((width, new_height), Image.LANCZOS)
                
                img.save(output_folder / file.name, optimize=True)
                count += 1
                print(f"Resized: {file.name}")
            except Exception as e:
                print(f"Error with {file.name}: {e}")
    
    print(f"Resized {count} images. Saved to: {output_folder}")

# Usage: batch_resize_images("C:/Photos", 800, 600)


# ============================================================
# 22. Convert Images to Another Format
# ============================================================
def convert_image_format(folder_path, to_format="webp", quality=85):
    """Convert all images in a folder to a different format."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    output_folder = folder / f"converted_{to_format}"
    output_folder.mkdir(exist_ok=True)
    
    extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp'}
    count = 0
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                new_name = file.stem + '.' + to_format
                if to_format.lower() == 'webp':
                    img.save(output_folder / new_name, 'WEBP', quality=quality)
                elif to_format.lower() == 'jpg' or to_format.lower() == 'jpeg':
                    img = img.convert('RGB')
                    img.save(output_folder / new_name, 'JPEG', quality=quality)
                else:
                    img.save(output_folder / new_name, to_format.upper())
                count += 1
                print(f"Converted: {file.name} -> {new_name}")
            except Exception as e:
                print(f"Error with {file.name}: {e}")
    
    print(f"Converted {count} images. Saved to: {output_folder}")

# Usage: convert_image_format("C:/Photos", "webp", 85)


# ============================================================
# 23. Add Watermark to Images
# ============================================================
def add_watermark(folder_path, watermark_text, output_folder=None):
    """Add text watermark to all images in a folder."""
    from PIL import Image, ImageDraw, ImageFont
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    if output_folder is None:
        output_folder = folder / "watermarked"
    output_folder = Path(output_folder)
    output_folder.mkdir(exist_ok=True)
    
    extensions = {'.jpg', '.jpeg', '.png', '.bmp'}
    count = 0
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                draw = ImageDraw.Draw(img)
                
                # Use default font
                try:
                    font = ImageFont.truetype("arial.ttf", size=max(12, img.width // 30))
                except:
                    font = ImageFont.load_default()
                
                # Position at bottom-right
                bbox = draw.textbbox((0, 0), watermark_text, font=font)
                text_width = bbox[2] - bbox[0]
                text_height = bbox[3] - bbox[1]
                x = img.width - text_width - 20
                y = img.height - text_height - 20
                
                # Draw semi-transparent text
                draw.text((x, y), watermark_text, font=font, fill=(255, 255, 255, 128))
                img.save(output_folder / file.name)
                count += 1
                print(f"Watermarked: {file.name}")
            except Exception as e:
                print(f"Error with {file.name}: {e}")
    
    print(f"Watermarked {count} images. Saved to: {output_folder}")

# Usage: add_watermark("C:/Photos", "© My Company")


# ============================================================
# 24. Create Image Thumbnails
# ============================================================
def create_thumbnails(folder_path, thumb_size=(200, 200)):
    """Create thumbnail versions of all images in a folder."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    output_folder = folder / "thumbnails"
    output_folder.mkdir(exist_ok=True)
    
    extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
    count = 0
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                img.thumbnail(thumb_size, Image.LANCZOS)
                img.save(output_folder / file.name, optimize=True)
                count += 1
                print(f"Thumbnail: {file.name}")
            except Exception as e:
                print(f"Error with {file.name}: {e}")
    
    print(f"Created {count} thumbnails. Saved to: {output_folder}")

# Usage: create_thumbnails("C:/Photos", (150, 150))


# ============================================================
# 25. Compress Images for Web
# ============================================================
def compress_images_for_web(folder_path, quality=70, max_width=1920):
    """Optimize images for web use by compressing and resizing."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    output_folder = folder / "optimized"
    output_folder.mkdir(exist_ok=True)
    
    extensions = {'.jpg', '.jpeg', '.png'}
    total_before = 0
    total_after = 0
    count = 0
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                before_size = file.stat().st_size
                total_before += before_size
                
                img = Image.open(file)
                
                # Resize if too wide
                if img.width > max_width:
                    ratio = max_width / img.width
                    new_height = int(img.height * ratio)
                    img = img.resize((max_width, new_height), Image.LANCZOS)
                
                # Convert to RGB if needed
                if img.mode in ('RGBA', 'P'):
                    img = img.convert('RGB')
                
                output_path = output_folder / (file.stem + '.jpg')
                img.save(output_path, 'JPEG', quality=quality, optimize=True)
                
                after_size = output_path.stat().st_size
                total_after += after_size
                saved = (1 - after_size / before_size) * 100
                count += 1
                print(f"Compressed: {file.name} - Saved {saved:.0f}%")
            except Exception as e:
                print(f"Error with {file.name}: {e}")
    
    total_saved = (1 - total_after / total_before) * 100 if total_before > 0 else 0
    print(f"\nCompressed {count} images")
    print(f"Total before: {total_before / 1024:.0f} KB")
    print(f"Total after:  {total_after / 1024:.0f} KB")
    print(f"Saved: {total_saved:.0f}%")

# Usage: compress_images_for_web("C:/Photos", quality=70)


# ============================================================
# 26. Extract Colors from Image
# ============================================================
def extract_colors(image_path, num_colors=5):
    """Extract dominant colors from an image."""
    from PIL import Image
    
    image_path = Path(image_path)
    if not image_path.exists():
        print(f"File not found: {image_path}")
        return
    
    try:
        img = Image.open(image_path)
        img = img.resize((100, 100))
        img = img.convert('RGB')
        
        colors = img.getcolors(maxcolors=10000)
        colors.sort(reverse=True)
        
        print(f"Dominant colors in {image_path.name}:")
        for i, (count, color) in enumerate(colors[:num_colors]):
            hex_color = '#{:02x}{:02x}{:02x}'.format(*color)
            percentage = count / (100 * 100) * 100
            print(f"  {i+1}. {hex_color} - {percentage:.1f}%")
        
        return [(count, color) for count, color in colors[:num_colors]]
    except Exception as e:
        print(f"Error: {e}")
        return []

# Usage: extract_colors("image.jpg", 5)


# ============================================================
# 27. Create Image Collage
# ============================================================
def create_collage(folder_path, output_path="collage.jpg", cols=3):
    """Create a collage from images in a folder."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    extensions = {'.jpg', '.jpeg', '.png'}
    images = []
    
    for file in folder.iterdir():
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                img.thumbnail((300, 300))
                images.append(img)
            except:
                pass
    
    if not images:
        print("No images found")
        return
    
    # Calculate grid
    rows = (len(images) + cols - 1) // cols
    thumb_w, thumb_h = 300, 300
    collage = Image.new('RGB', (cols * thumb_w, rows * thumb_h), 'white')
    
    for i, img in enumerate(images):
        row = i // cols
        col = i % cols
        x = col * thumb_w + (thumb_w - img.width) // 2
        y = row * thumb_h + (thumb_h - img.height) // 2
        collage.paste(img, (x, y))
    
    collage.save(output_path, 'JPEG', quality=90)
    print(f"Collage created: {output_path}")

# Usage: create_collage("C:/Photos", "my_collage.jpg", 4)


# ============================================================
# 28. Get Image EXIF Data
# ============================================================
def get_exif_data(image_path):
    """Extract EXIF metadata from an image."""
    from PIL import Image
    from PIL.ExifTags import TAGS
    
    image_path = Path(image_path)
    if not image_path.exists():
        print(f"File not found: {image_path}")
        return
    
    try:
        img = Image.open(image_path)
        exif_data = img._getexif()
        
        if exif_data:
            print(f"EXIF data for {image_path.name}:")
            for tag_id, value in exif_data.items():
                tag_name = TAGS.get(tag_id, tag_id)
                if isinstance(value, bytes):
                    value = value.decode('utf-8', errors='ignore')
                print(f"  {tag_name}: {value}")
        else:
            print("No EXIF data found")
    except Exception as e:
        print(f"Error: {e}")

# Usage: get_exif_data("photo.jpg")


# ============================================================
# 29. Create PDF from Images
# ============================================================
def images_to_pdf(folder_path, output_pdf="output.pdf"):
    """Combine multiple images into a single PDF file."""
    from PIL import Image
    
    folder = Path(folder_path)
    if not folder.exists():
        print(f"Folder not found: {folder_path}")
        return
    
    extensions = {'.jpg', '.jpeg', '.png', '.bmp'}
    images = []
    
    for file in sorted(folder.iterdir()):
        if file.is_file() and file.suffix.lower() in extensions:
            try:
                img = Image.open(file)
                if img.mode == 'RGBA':
                    img = img.convert('RGB')
                images.append(img)
            except:
                pass
    
    if images:
        images[0].save(output_pdf, save_all=True, append_images=images[1:])
        print(f"PDF created with {len(images)} pages: {output_pdf}")
    else:
        print("No images found")

# Usage: images_to_pdf("C:/Scans", "document.pdf")


# ============================================================
# 30. Generate QR Code
# ============================================================
def generate_qr(data, output_path="qrcode.png", size=300):
    """Generate a QR code image from text or URL."""
    try:
        import qrcode
        from PIL import Image
        
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        img = img.resize((size, size), Image.LANCZOS)
        img.save(output_path)
        print(f"QR code saved: {output_path}")
    except ImportError:
        print("Please install qrcode: pip install qrcode[pil]")
    except Exception as e:
        print(f"Error: {e}")

# Usage: generate_qr("https://www.cairosoftware.com", "cairo_qr.png")

"""
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
"""