/*
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 11. Select Element by CSS Selector
// ============================================================
function $(selector) {
    return document.querySelector(selector);
}
function $$(selector) {
    return document.querySelectorAll(selector);
}
// Usage: $("#myButton") → single element
// Usage: $$(".items") → NodeList of elements

// ============================================================
// 12. Add Class to Element
// ============================================================
function addClass(element, className) {
    if (element) element.classList.add(className);
}
// Usage: addClass(document.getElementById("box"), "active");

// ============================================================
// 13. Remove Class from Element
// ============================================================
function removeClass(element, className) {
    if (element) element.classList.remove(className);
}
// Usage: removeClass(document.getElementById("box"), "hidden");

// ============================================================
// 14. Toggle Class on Element
// ============================================================
function toggleClass(element, className) {
    if (element) element.classList.toggle(className);
}
// Usage: toggleClass(document.getElementById("menu"), "open");

// ============================================================
// 15. Check if Element Has Class
// ============================================================
function hasClass(element, className) {
    return element ? element.classList.contains(className) : false;
}
// Usage: hasClass(document.getElementById("box"), "active") → true or false

// ============================================================
// 16. Get or Set Text Content
// ============================================================
function text(element, content) {
    if (!element) return '';
    if (content !== undefined) {
        element.textContent = content;
    }
    return element.textContent;
}
// Usage: text($("#title"), "New Title"); → sets text
// Usage: text($("#title")); → gets text

// ============================================================
// 17. Get or Set HTML Content
// ============================================================
function html(element, content) {
    if (!element) return '';
    if (content !== undefined) {
        element.innerHTML = content;
    }
    return element.innerHTML;
}
// Usage: html($("#container"), "<p>Hello</p>"); → sets HTML
// Usage: html($("#container")); → gets HTML

// ============================================================
// 18. Show Element
// ============================================================
function show(element) {
    if (element) element.style.display = '';
}
// Usage: show(document.getElementById("popup"));

// ============================================================
// 19. Hide Element
// ============================================================
function hide(element) {
    if (element) element.style.display = 'none';
}
// Usage: hide(document.getElementById("popup"));

// ============================================================
// 20. Create Element with Attributes and Content
// ============================================================
function createElement(tag, attrs, content) {
    var el = document.createElement(tag);
    if (attrs) {
        for (var key in attrs) {
            if (key === 'class') {
                el.className = attrs[key];
            } else if (key === 'style' && typeof attrs[key] === 'object') {
                for (var prop in attrs[key]) {
                    el.style[prop] = attrs[key][prop];
                }
            } else {
                el.setAttribute(key, attrs[key]);
            }
        }
    }
    if (content) el.innerHTML = content;
    return el;
}
// Usage: createElement('button', {class: 'btn', id: 'myBtn'}, 'Click Me');

/*
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
*/