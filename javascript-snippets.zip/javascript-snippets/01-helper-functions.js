/*
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 1. Generate Random Number Between Two Values
// ============================================================
function randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
// Usage: randomBetween(1, 100) → random number from 1 to 100

// ============================================================
// 2. Capitalize First Letter of Each Word
// ============================================================
function capitalizeWords(str) {
    return str.replace(/\b\w/g, function(char) { return char.toUpperCase(); });
}
// Usage: capitalizeWords("hello world") → "Hello World"

// ============================================================
// 3. Convert String to Slug (URL-friendly)
// ============================================================
function stringToSlug(str) {
    return str.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');
}
// Usage: stringToSlug("Hello World Example") → "hello-world-example"

// ============================================================
// 4. Truncate Text with Ellipsis
// ============================================================
function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength).trim() + '...';
}
// Usage: truncateText("This is a long sentence", 10) → "This is a..."

// ============================================================
// 5. Get Current Date in Different Formats
// ============================================================
function formatDate(date, format) {
    var d = new Date(date);
    var year = d.getFullYear();
    var month = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    var formats = {
        'YYYY-MM-DD': year + '-' + month + '-' + day,
        'DD/MM/YYYY': day + '/' + month + '/' + year,
        'MM/DD/YYYY': month + '/' + day + '/' + year,
        'full': d.toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })
    };
    return formats[format] || formats['YYYY-MM-DD'];
}
// Usage: formatDate(new Date(), 'DD/MM/YYYY') → "09/08/2026"

// ============================================================
// 6. Check if Email is Valid
// ============================================================
function isValidEmail(email) {
    var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return pattern.test(email);
}
// Usage: isValidEmail("test@example.com") → true

// ============================================================
// 7. Check if Password is Strong
// ============================================================
function isStrongPassword(password) {
    var minLength = 8;
    var hasUpper = /[A-Z]/.test(password);
    var hasLower = /[a-z]/.test(password);
    var hasNumber = /[0-9]/.test(password);
    var hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return password.length >= minLength && hasUpper && hasLower && hasNumber && hasSpecial;
}
// Usage: isStrongPassword("MyP@ssw0rd") → true

// ============================================================
// 8. Debounce Function (Limit How Often a Function Runs)
// ============================================================
function debounce(func, delay) {
    var timeout;
    return function() {
        var context = this;
        var args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(function() { func.apply(context, args); }, delay);
    };
}
// Usage: window.addEventListener('resize', debounce(function(){ console.log('Resized'); }, 300));

// ============================================================
// 9. Throttle Function (Ensure Function Runs at Most Once Per Interval)
// ============================================================
function throttle(func, limit) {
    var inThrottle;
    return function() {
        var context = this;
        var args = arguments;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(function() { inThrottle = false; }, limit);
        }
    };
}
// Usage: window.addEventListener('scroll', throttle(function(){ console.log('Scrolled'); }, 200));

// ============================================================
// 10. Copy Text to Clipboard
// ============================================================
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            console.log('Text copied to clipboard');
        }).catch(function(err) {
            console.error('Failed to copy: ', err);
        });
    } else {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
    }
}
// Usage: copyToClipboard("Hello World");

/*
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
*/