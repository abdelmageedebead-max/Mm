/*
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 31. Remove Duplicates from Array
// ============================================================
function removeDuplicates(arr) {
    return [...new Set(arr)];
}
// Usage: removeDuplicates([1,2,2,3,3,4]) → [1,2,3,4]

// ============================================================
// 32. Shuffle Array (Fisher-Yates Algorithm)
// ============================================================
function shuffleArray(arr) {
    var shuffled = [...arr];
    for (var i = shuffled.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = shuffled[i];
        shuffled[i] = shuffled[j];
        shuffled[j] = temp;
    }
    return shuffled;
}
// Usage: shuffleArray([1,2,3,4,5]) → random order

// ============================================================
// 33. Group Array of Objects by Property
// ============================================================
function groupBy(arr, property) {
    return arr.reduce(function(groups, item) {
        var key = item[property];
        if (!groups[key]) groups[key] = [];
        groups[key].push(item);
        return groups;
    }, {});
}
// Usage: groupBy(users, 'role') → {admin: [...], editor: [...]}

// ============================================================
// 34. Sort Array of Objects by Property
// ============================================================
function sortBy(arr, property, ascending) {
    return [...arr].sort(function(a, b) {
        if (a[property] < b[property]) return ascending ? -1 : 1;
        if (a[property] > b[property]) return ascending ? 1 : -1;
        return 0;
    });
}
// Usage: sortBy(users, 'name', true) → sorted alphabetically

// ============================================================
// 35. Find Object in Array by Property
// ============================================================
function findBy(arr, property, value) {
    return arr.find(function(item) { return item[property] === value; });
}
// Usage: findBy(users, 'id', 5) → {id: 5, name: "John"}

// ============================================================
// 36. Deep Clone Object or Array
// ============================================================
function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}
// Usage: deepClone({name: "John", items: [1,2,3]}) → new independent copy

// ============================================================
// 37. Merge Two Objects
// ============================================================
function mergeObjects(obj1, obj2) {
    return Object.assign({}, obj1, obj2);
}
// Usage: mergeObjects({a:1}, {b:2}) → {a:1, b:2}

// ============================================================
// 38. Format Number as Currency
// ============================================================
function formatCurrency(amount, currency, locale) {
    return new Intl.NumberFormat(locale || 'en-US', {
        style: 'currency',
        currency: currency || 'USD'
    }).format(amount);
}
// Usage: formatCurrency(1250.5, 'USD', 'en-US') → "$1,250.50"
// Usage: formatCurrency(1250.5, 'SAR', 'ar-SA') → "١٬٢٥٠٫٥٠ ر.س"

// ============================================================
// 39. Format File Size
// ============================================================
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    var i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(1)) + ' ' + sizes[i];
}
// Usage: formatFileSize(1536000) → "1.5 MB"

// ============================================================
// 40. Get URL Parameters as Object
// ============================================================
function getURLParams() {
    var params = {};
    var queryString = window.location.search.substring(1);
    var pairs = queryString.split('&');
    pairs.forEach(function(pair) {
        if (pair) {
            var parts = pair.split('=');
            params[decodeURIComponent(parts[0])] = decodeURIComponent(parts[1] || '');
        }
    });
    return params;
}
// Usage: URL is ?name=John&age=30 → {name: "John", age: "30"}

/*
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
*/