/*
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 41. Save to Local Storage
// ============================================================
function saveToStorage(key, value) {
    try {
        var serialized = JSON.stringify(value);
        localStorage.setItem(key, serialized);
        return true;
    } catch (e) {
        console.error('Failed to save to localStorage:', e);
        return false;
    }
}
// Usage: saveToStorage("userSettings", {theme: "dark", lang: "en"});

// ============================================================
// 42. Load from Local Storage
// ============================================================
function loadFromStorage(key, defaultValue) {
    try {
        var item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
        console.error('Failed to load from localStorage:', e);
        return defaultValue;
    }
}
// Usage: loadFromStorage("userSettings", {theme: "light"});

// ============================================================
// 43. Remove from Local Storage
// ============================================================
function removeFromStorage(key) {
    try {
        localStorage.removeItem(key);
    } catch (e) {
        console.error('Failed to remove from localStorage:', e);
    }
}
// Usage: removeFromStorage("tempData");

// ============================================================
// 44. Set Cookie
// ============================================================
function setCookie(name, value, days) {
    var expires = '';
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = '; expires=' + date.toUTCString();
    }
    document.cookie = name + '=' + encodeURIComponent(value) + expires + '; path=/; SameSite=Lax';
}
// Usage: setCookie("username", "john", 7);

// ============================================================
// 45. Get Cookie
// ============================================================
function getCookie(name) {
    var nameEQ = name + '=';
    var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i].trim();
        if (cookie.indexOf(nameEQ) === 0) {
            return decodeURIComponent(cookie.substring(nameEQ.length, cookie.length));
        }
    }
    return null;
}
// Usage: getCookie("username") → "john"

// ============================================================
// 46. Fade In Element
// ============================================================
function fadeIn(element, duration) {
    if (!element) return;
    element.style.opacity = '0';
    element.style.display = '';
    var start = performance.now();
    function animate(time) {
        var elapsed = time - start;
        var progress = Math.min(elapsed / (duration || 400), 1);
        element.style.opacity = progress;
        if (progress < 1) requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);
}
// Usage: fadeIn(document.getElementById("popup"), 500);

// ============================================================
// 47. Fade Out Element
// ============================================================
function fadeOut(element, duration) {
    if (!element) return;
    var start = performance.now();
    function animate(time) {
        var elapsed = time - start;
        var progress = Math.min(elapsed / (duration || 400), 1);
        element.style.opacity = 1 - progress;
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            element.style.display = 'none';
        }
    }
    requestAnimationFrame(animate);
}
// Usage: fadeOut(document.getElementById("popup"), 500);

// ============================================================
// 48. Smooth Scroll to Element
// ============================================================
function scrollToElement(selector) {
    var element = document.querySelector(selector);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}
// Usage: scrollToElement("#section2");

// ============================================================
// 49. Detect Dark Mode Preference
// ============================================================
function prefersDarkMode() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}
// Usage: prefersDarkMode() → true or false

// ============================================================
// 50. Detect Mobile Device
// ============================================================
function isMobileDevice() {
    return /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}
// Usage: isMobileDevice() → true or false

/*
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com         ║
╚══════════════════════════════════════════════════════════════╝
*/