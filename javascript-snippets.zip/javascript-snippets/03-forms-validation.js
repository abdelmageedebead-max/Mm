/*
╔══════════════════════════════════════════════════════════════╗
║  CairoSoftware - www.cairosoftware.com                       ║
║  © 2026 CairoSoftware. All Rights Reserved.                  ║
║  Free resource for learning and personal use.                ║
║  Redistribution or reselling without attribution prohibited. ║
╚══════════════════════════════════════════════════════════════╝
*/

// ============================================================
// 21. Validate Required Fields
// ============================================================
function validateRequired(formSelector) {
    var form = document.querySelector(formSelector);
    if (!form) return false;
    var inputs = form.querySelectorAll('[required]');
    var isValid = true;
    inputs.forEach(function(input) {
        if (!input.value.trim()) {
            input.style.borderColor = 'red';
            isValid = false;
        } else {
            input.style.borderColor = '#ddd';
        }
    });
    return isValid;
}
// Usage: validateRequired("#contactForm") → true or false

// ============================================================
// 22. Get All Form Values as Object
// ============================================================
function getFormValues(formSelector) {
    var form = document.querySelector(formSelector);
    var data = {};
    if (!form) return data;
    var inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(function(input) {
        if (input.name) {
            if (input.type === 'checkbox') {
                data[input.name] = input.checked;
            } else if (input.type === 'radio') {
                if (input.checked) data[input.name] = input.value;
            } else {
                data[input.name] = input.value;
            }
        }
    });
    return data;
}
// Usage: getFormValues("#loginForm") → {email: "test@test.com", password: "1234"}

// ============================================================
// 23. Reset Form to Empty
// ============================================================
function resetForm(formSelector) {
    var form = document.querySelector(formSelector);
    if (!form) return;
    form.reset();
    var inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(function(input) {
        input.style.borderColor = '#ddd';
    });
}
// Usage: resetForm("#contactForm");

// ============================================================
// 24. Validate Phone Number
// ============================================================
function isValidPhone(phone) {
    if (!phone || typeof phone !== 'string') return false;
    var digits = phone.replace(/\D/g, '');
    if (digits.length < 7 || digits.length > 15) return false;
    var pattern = /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,4}[-\s\.]?[0-9]{1,9}$/;
    return pattern.test(phone);
}
// Usage: isValidPhone("+1-555-123-4567") → true
// Usage: isValidPhone("123") → false

// ============================================================
// 25. Validate URL
// ============================================================
function isValidURL(url) {
    if (!url || typeof url !== 'string') return false;
    var pattern = /^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w- .\/?%&=]*)?$/;
    return pattern.test(url);
}
// Usage: isValidURL("https://www.example.com") → true
// Usage: isValidURL("not a url") → false

// ============================================================
// 26. Count Characters in Textarea
// ============================================================
function setupCharCounter(textareaSelector, counterSelector, maxChars) {
    var textarea = document.querySelector(textareaSelector);
    var counter = document.querySelector(counterSelector);
    if (!textarea || !counter) return;
    textarea.addEventListener('input', function() {
        var remaining = maxChars - this.value.length;
        counter.textContent = this.value.length + '/' + maxChars;
        counter.style.color = remaining < 10 ? 'red' : '#666';
    });
}
// Usage: setupCharCounter("#message", "#charCount", 200);

// ============================================================
// 27. Auto-Resize Textarea
// ============================================================
function autoResizeTextarea(textareaSelector) {
    var textarea = document.querySelector(textareaSelector);
    if (!textarea) return;
    textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
    });
}
// Usage: autoResizeTextarea("#message");

// ============================================================
// 28. Limit Checkbox Selection
// ============================================================
function limitCheckboxSelection(groupName, maxAllowed) {
    var checkboxes = document.querySelectorAll('input[name="' + groupName + '"]');
    checkboxes.forEach(function(cb) {
        cb.addEventListener('change', function() {
            var checked = document.querySelectorAll('input[name="' + groupName + '"]:checked');
            if (checked.length > maxAllowed) {
                this.checked = false;
                alert('You can only select ' + maxAllowed + ' options.');
            }
        });
    });
}
// Usage: limitCheckboxSelection("interests", 3);

// ============================================================
// 29. Show Password Toggle
// ============================================================
function setupPasswordToggle(inputSelector, toggleSelector) {
    var input = document.querySelector(inputSelector);
    var toggle = document.querySelector(toggleSelector);
    if (!input || !toggle) return;
    toggle.addEventListener('click', function() {
        var type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        toggle.textContent = type === 'password' ? 'Show' : 'Hide';
    });
}
// Usage: setupPasswordToggle("#password", "#toggleBtn");

// ============================================================
// 30. Submit Form via AJAX
// ============================================================
function submitFormAjax(formSelector, url, callback) {
    var form = document.querySelector(formSelector);
    if (!form) return;
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(form);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                callback(null, xhr.responseText);
            } else {
                callback(new Error('Request failed: ' + xhr.status));
            }
        };
        xhr.onerror = function() {
            callback(new Error('Network error'));
        };
        xhr.send(formData);
    });
}
// Usage: submitFormAjax("#contactForm", "/api/contact", function(err, response){ console.log(response); });

/*
╔══════════════════════════════════════════════════════════════╗
║  End of file - CairoSoftware - www.cairosoftware.com        ║
╚══════════════════════════════════════════════════════════════╝
*/