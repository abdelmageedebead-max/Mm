const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const QRCode = require('qrcode');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const now = () => new Date().toISOString();
const makeCode = (prefix) =>
  `ZN-${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

async function query(text, params = []) {
  const result = await pool.query(text, params);
  return result.rows;
}

async function initDatabase() {
  await query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'admin',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS members (
      id SERIAL PRIMARY KEY,
      member_no TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      phone TEXT DEFAULT '',
      position TEXT DEFAULT '',
      status TEXT DEFAULT 'active',
      notes TEXT DEFAULT '',
      created_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS cards (
      id SERIAL PRIMARY KEY,
      card_no TEXT UNIQUE NOT NULL,
      member_id INT REFERENCES members(id) ON DELETE CASCADE,
      token TEXT UNIQUE NOT NULL,
      issued_at TIMESTAMPTZ DEFAULT NOW(),
      expires_at TEXT DEFAULT '',
      status TEXT DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS payments (
      id SERIAL PRIMARY KEY,
      receipt_no TEXT UNIQUE NOT NULL,
      member_id INT REFERENCES members(id) ON DELETE SET NULL,
      member_name TEXT DEFAULT '',
      amount NUMERIC DEFAULT 0,
      purpose TEXT DEFAULT '',
      paid_at TIMESTAMPTZ DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS ads (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT DEFAULT '',
      published_at TIMESTAMPTZ DEFAULT NOW(),
      status TEXT DEFAULT 'published'
    );
  `);

  const users = await query('SELECT id FROM users LIMIT 1');
  if (users.length === 0) {
    const passwordHash = bcrypt.hashSync('Admin@12345', 10);
    await query(
      'INSERT INTO users(username, password_hash, role, created_at) VALUES($1, $2, $3, $4)',
      ['admin', passwordHash, 'admin', now()]
    );
  }
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'ZENOVA Center Management System' });
});

app.post('/api/login', async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const users = await query('SELECT * FROM users WHERE username = $1 LIMIT 1', [username]);

    if (users.length === 0 || !bcrypt.compareSync(password, users[0].password_hash)) {
      return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
    }

    return res.json({ ok: true, user: { id: users[0].id, username: users[0].username, role: users[0].role } });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'حدث خطأ في الخادم' });
  }
});

app.get('/api/dashboard', async (req, res) => {
  try {
    const [members, cards, payments, ads] = await Promise.all([
      query('SELECT COUNT(*)::int AS n FROM members'),
      query("SELECT COUNT(*)::int AS n FROM cards WHERE status = 'active'"),
      query('SELECT COALESCE(SUM(amount), 0)::numeric AS n FROM payments'),
      query('SELECT COUNT(*)::int AS n FROM ads')
    ]);

    res.json({
      members: members[0].n,
      cards: cards[0].n,
      payments: payments[0].n,
      ads: ads[0].n
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'تعذر تحميل لوحة المعلومات' });
  }
});

app.get('/api/members', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM members ORDER BY id DESC');
    res.json(rows);
  } catch (error) {
    console.error('Members error:', error);
    res.status(500).json({ error: 'تعذر تحميل الأعضاء' });
  }
});

app.post('/api/members', async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    if (!name) return res.status(400).json({ error: 'اسم العضو مطلوب' });

    const rows = await query(
      `INSERT INTO members(member_no, name, phone, position, notes, created_at)
       VALUES($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        makeCode('M'),
        name,
        String(req.body.phone || ''),
        String(req.body.position || ''),
        String(req.body.notes || ''),
        now()
      ]
    );

    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Create member error:', error);
    res.status(500).json({ error: 'تعذر إضافة العضو' });
  }
});

app.get('/api/cards', async (req, res) => {
  try {
    const rows = await query(
      `SELECT c.*, m.name, m.member_no, m.position
       FROM cards c
       JOIN members m ON m.id = c.member_id
       ORDER BY c.id DESC`
    );
    res.json(rows);
  } catch (error) {
    console.error('Cards error:', error);
    res.status(500).json({ error: 'تعذر تحميل البطاقات' });
  }
});

app.post('/api/cards', async (req, res) => {
  try {
    const memberId = Number(req.body.member_id);
    if (!Number.isInteger(memberId)) {
      return res.status(400).json({ error: 'رقم العضو غير صحيح' });
    }

    const members = await query('SELECT * FROM members WHERE id = $1 LIMIT 1', [memberId]);
    if (members.length === 0) return res.status(404).json({ error: 'العضو غير موجود' });

    const member = members[0];
    const rows = await query(
      `INSERT INTO cards(card_no, member_id, token, issued_at, expires_at, status)
       VALUES($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        makeCode('C'),
        member.id,
        crypto.randomBytes(18).toString('hex'),
        now(),
        String(req.body.expires_at || ''),
        'active'
      ]
    );

    res.status(201).json({ ...rows[0], name: member.name, member_no: member.member_no, position: member.position });
  } catch (error) {
    console.error('Create card error:', error);
    res.status(500).json({ error: 'تعذر إنشاء البطاقة' });
  }
});

app.get('/api/cards/:id/qr', async (req, res) => {
  try {
    const rows = await query('SELECT token FROM cards WHERE id = $1 LIMIT 1', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'البطاقة غير موجودة' });

    const baseUrl = process.env.PUBLIC_BASE_URL || `${req.protocol}://${req.get('host')}`;
    const url = `${baseUrl}/verify/${encodeURIComponent(rows[0].token)}`;
    const data = await QRCode.toDataURL(url, { width: 280, margin: 1 });

    res.json({ url, data });
  } catch (error) {
    console.error('QR error:', error);
    res.status(500).json({ error: 'تعذر إنشاء رمز QR' });
  }
});

app.get('/verify/:token', async (req, res) => {
  try {
    const rows = await query(
      `SELECT c.card_no, c.issued_at, c.expires_at, c.status,
              m.name, m.member_no, m.position, m.status AS member_status
       FROM cards c
       JOIN members m ON m.id = c.member_id
       WHERE c.token = $1
       LIMIT 1`,
      [req.params.token]
    );

    if (rows.length === 0) return res.status(404).send('البطاقة غير موجودة');

    const card = rows[0];
    const safe = (value) => String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');

    const html = [
      '<!doctype html>',
      '<html lang="ar" dir="rtl">',
      '<head>',
      '<meta charset="utf-8">',
      '<meta name="viewport" content="width=device-width,initial-scale=1">',
      '<title>التحقق من بطاقة ZENOVA</title>',
      '<style>',
      'body{font-family:Arial,Tahoma,sans-serif;background:#f4f7fb;margin:0;padding:30px;color:#172033}',
      '.card{max-width:560px;margin:30px auto;background:#fff;border-radius:18px;padding:28px;box-shadow:0 8px 30px rgba(0,0,0,.08)}',
      'h1{text-align:center;color:#123b63;margin-top:0}',
      '.ok{background:#e9f8ef;color:#18733a;padding:12px;border-radius:10px;text-align:center;font-weight:bold;margin-bottom:18px}',
      '.row{padding:12px 0;border-bottom:1px solid #eee}',
      '.label{font-weight:bold}',
      '</style>',
      '</head>',
      '<body>',
      '<main class="card">',
      '<h1>ZENOVA</h1>',
      '<div class="ok">تم التحقق من البطاقة</div>',
      `<div class="row"><span class="label">الاسم:</span> ${safe(card.name)}</div>`,
      `<div class="row"><span class="label">رقم العضوية:</span> ${safe(card.member_no)}</div>`,
      `<div class="row"><span class="label">الصفة:</span> ${safe(card.position)}</div>`,
      `<div class="row"><span class="label">رقم البطاقة:</span> ${safe(card.card_no)}</div>`,
      `<div class="row"><span class="label">الحالة:</span> ${safe(card.status)}</div>`,
      `<div class="row"><span class="label">تاريخ الإصدار:</span> ${safe(card.issued_at)}</div>`,
      `<div class="row"><span class="label">تاريخ الانتهاء:</span> ${safe(card.expires_at || 'غير محدد')}</div>`,
      '</main>',
      '</body>',
      '</html>'
    ].join('');

    res.type('html').send(html);
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).send('حدث خطأ في الخادم');
  }
});

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'المسار غير موجود' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'), (error) => {
    if (error) res.status(404).send('ZENOVA: الصفحة غير موجودة');
  });
});

async function start() {
  try {
    await initDatabase();
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`ZENOVA server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Database initialization failed:', error);
    process.exit(1);
  }
}

start();
